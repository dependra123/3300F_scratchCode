
class util {
    public:
        static int sign(double x);
        static double clamp(double x, double min, double max);
};